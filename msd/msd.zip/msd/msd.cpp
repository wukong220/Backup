#include <fstream>
#include <math.h>
#include <time.h>

int main() 
{
	using namespace std;
	
	ostream fout;
	srand((unsigned int)(time(NULL)));
	double ran = rand() / RAND_MAX - 0.5;
	
	cout << 
	return 0;
}